for (let key in process.env) {
  console.log(`${key} : ${process.env[key]}`);
}