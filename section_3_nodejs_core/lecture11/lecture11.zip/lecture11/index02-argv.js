for (let i = 0, max = process.argv.length; i < max; i++) {
  console.log(`${i}: ${process.argv[i]}`);
}
