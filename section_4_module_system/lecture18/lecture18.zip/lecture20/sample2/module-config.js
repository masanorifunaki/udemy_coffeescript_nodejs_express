module.exports = {
  display: {
    fontSize: 10,
    fontWeight: "normal",
    fontColor: "white"
  }
}