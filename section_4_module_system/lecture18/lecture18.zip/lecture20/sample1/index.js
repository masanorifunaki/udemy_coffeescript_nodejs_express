
console.log("start.");

require("./module-a.js");

console.log("end");

