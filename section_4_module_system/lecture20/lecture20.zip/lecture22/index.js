module.exports = function (message) {
  console.log(`\u001b[36m${message}\u001b[0m`);
};