var log = function (message) {
  var date = (new Date()).toISOString();
  console.log(date + ":" + message);
};