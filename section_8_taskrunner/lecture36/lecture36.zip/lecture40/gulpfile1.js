var gulp = require("gulp");

gulp.task("default", () => {
  console.log("Hello World.");
});
