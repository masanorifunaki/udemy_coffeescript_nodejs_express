var gulp = require("gulp");
var rename = require("gulp-rename");

gulp.task("rename", () => {
  gulp.src("./src/sample1.txt")
    .pipe(rename("hoge.txt"))
    .pipe(gulp.dest("./dist"));
});

gulp.task("default", ["rename"]);
