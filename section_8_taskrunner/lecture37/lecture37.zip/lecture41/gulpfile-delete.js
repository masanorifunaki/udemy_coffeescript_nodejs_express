var gulp = require("gulp");
var del = require("del");

gulp.task("delete", () => {
  return del("./dist/*")
});

gulp.task("default", ["delete"]);