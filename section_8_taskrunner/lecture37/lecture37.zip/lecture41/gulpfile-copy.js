var gulp = require("gulp");

gulp.task("copy", () => {
  gulp.src("./src/sample1.txt")
    .pipe(gulp.dest("./dist"));
});

gulp.task("default", ["copy"]);