module.exports = {
  search: {
    MAX_ITEMS_PER_PAGE: 2
  }
};