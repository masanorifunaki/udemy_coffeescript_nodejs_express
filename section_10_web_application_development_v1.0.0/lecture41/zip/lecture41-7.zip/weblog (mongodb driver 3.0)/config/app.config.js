module.exports = {
  security: {
    SESSION_SECRET: "salt"
  },
  search: {
    MAX_ITEMS_PER_PAGE: 2
  }
};