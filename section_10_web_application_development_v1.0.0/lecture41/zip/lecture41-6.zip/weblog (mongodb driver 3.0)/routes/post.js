var router = require("express").Router();
var { CONNECTION_URL, DATABASE } = require("../config/mongodb.config.js");
var MongoClient = require("mongodb").MongoClient;

router.get("/*", (req, res) => {
  MongoClient.connect(CONNECTION_URL).then((client) => {
    var query = {
      url: { $eq: req.url }
    };
    return client.db(DATABASE).collection("posts")
      .findOne(query);
  }).then((data) => {
    res.render("./post/index.ejs", data);
  }).catch((err) => {
    throw err;
  });
});

module.exports = router;