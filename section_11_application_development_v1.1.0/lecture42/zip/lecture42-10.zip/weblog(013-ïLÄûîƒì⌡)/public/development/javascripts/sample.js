var sample = function (message) {
  message += "hoge";
  console.log(message);
};
sample();