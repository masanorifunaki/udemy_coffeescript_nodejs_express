var sample = function (message) {
  message += "HOGE";
  console.log(message);
};
sample();