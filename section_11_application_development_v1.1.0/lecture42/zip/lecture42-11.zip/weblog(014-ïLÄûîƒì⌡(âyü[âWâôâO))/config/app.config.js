module.exports = {
  search: {
    MAX_ITEM_PER_PAGE: 2
  }
};