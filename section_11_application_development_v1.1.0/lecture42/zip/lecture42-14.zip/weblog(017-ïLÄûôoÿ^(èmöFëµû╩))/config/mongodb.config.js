module.exports = {
  CONNECTION_URL: "mongodb://user:user@localhost:27017/weblog",
  DATABSE: "weblog",
  OPTIONS: {
    family: 4
  }
};